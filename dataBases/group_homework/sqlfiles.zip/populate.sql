DELETE FROM members;
DELETE FROM publishers;
DELETE FROM authors;
DELETE FROM books;
DELETE FROM reservations;

INSERT INTO members(member_name,phone,email) VALUES ("Neco", 914256769,"neco@gmail.com");
INSERT INTO members(member_name,phone,email) VALUES ("Tiago",931425698,"tiago@gmail.com");
INSERT INTO members(member_name,phone,email) VALUES ("Diney",961425698,"diney@gmail.com");

INSERT INTO publishers(publisher_name) VALUES ("Porto Editora");
INSERT INTO publishers(publisher_name) VALUES ("Leya");
INSERT INTO publishers(publisher_name) VALUES ("Odysseias");

INSERT INTO authors(author_name) VALUES ("Tolstoi");
INSERT INTO authors(author_name) VALUES ("Saramago");
INSERT INTO authors(author_name) VALUES ("Fernando Pessoa");

INSERT INTO books(book_name, date_released, author_id, publisher_id) VALUES
("Ensaio cegueira","1985-11-01", 2, 3);
INSERT INTO books(book_name, date_released, author_id, publisher_id) VALUES
("War and Peace", "1805-11-09", 1, 1);
INSERT INTO books(book_name, date_released, author_id, publisher_id) VALUES
("A Mensagem","1975-10-10",3, 2);


INSERT INTO reservations(loan_date, expected_date_return, return_daten) VALUES
(1, 2 , "2020-07-28", 2020-08-03);
INSERT INTO reservations(loan_date, expected_date_return, return_daten) VALUES
(2, 1 , "2019-10-07","2019-10-15","2019-10-20");
INSERT INTO reservations(loan_date, expected_date_return, return_daten) VALUES
(3, 3 , "2020-07-22", "2020-07-28");




